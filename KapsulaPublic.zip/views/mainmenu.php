<div class="d-flex justify-content-around p-4 bg-kuality">
    <img src="../imgs/mainlogo.png" alt="" height="60rem" width="60rem">
    <h1 class="titulo" height="20rem" width="100rem">KAPSULA</h1>
    <img src="../imgs/cavila.png" alt="" height="60rem" width="100rem">
</div>

<style>
    @font-face {
        font-family: "Varsity";
        font-style: normal;
        src: url("../fonts/varsity_regular.otf");
    }
    .titulo{
        font-family: "Varsity";
    }
</style>