<?php
class ControllerPlantilla{
    public function cTraerPlantilla(){
        include("views/plantilla.php");
    }
}

?>





